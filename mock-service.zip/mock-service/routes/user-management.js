import express from 'express'

const router = express.Router()

router.get('/user', (req, res, next) => {
    setTimeout(() => {
        res
            .status(200)
            .json({
                "tenantName": "iPoint-systems gmbh",
                "tenantId": "018e7e53-2083-768c-bde1-08cddf9ccc3f",
                "email": "tuan_user@platformdevcustomers.onmicrosoft.com",
                "firstName": "Tuan 01",
                "lastName": "Owner",
                "photoLink": "''",
                "userGroups": [
                    "Account User",
                    "Platform Owner",
                    "Test User Group 1"
                ]
            })
    }, 2000)
})

router.get('/users', (req, res, next) => {
    setTimeout(() => {
        res
            .status(200)
            .json({
                "pageIndex": 0,
                "pageSize": 25,
                "totalRecords": 5,
                "totalPages": 1,
                "hasPreviousPage": false,
                "hasNextPage": true,
                "data": [
                    {
                        "id": "68460000-0faa-0009-b0ee-08dd00e5c290",
                        "email": "tuan_user_test01@platformdevcustomers.onmicrosoft.com",
                        "firstName": "Tuan",
                        "lastName": "Mai",
                        "status": "VerificationExpired",
                        "userGroups": "Account User, Test User Group 1, Test User Group 2",
                        "lastLoginTimestamp": null
                    },
                    {
                        "id": "c46a0000-0faa-0009-6385-08dd2bc73310",
                        "email": "tuan_user_test03@yopmail.com",
                        "firstName": "Tuan 03",
                        "lastName": "Mai",
                        "status": "VerificationPending",
                        "userGroups": "Account User",
                        "lastLoginTimestamp": null
                    },
                    {
                        "id": "e41e0000-0faa-0009-8ae8-08dd137d8a7e",
                        "email": "tuan_user_test02@yopmail.com",
                        "firstName": "Tuan Test 02",
                        "lastName": "Mai",
                        "status": "VerificationExpired",
                        "userGroups": "Account User",
                        "lastLoginTimestamp": null
                    },
                    {
                        "id": "a8420000-0faa-0009-9522-08dd1355625f",
                        "email": "tuan_user01@yopmail.com",
                        "firstName": "Tuan User 01",
                        "lastName": "Mai asdfsdfasdf",
                        "status": "VerificationExpired",
                        "userGroups": "Account User",
                        "lastLoginTimestamp": null
                    },
                    {
                        "id": "8c740000-0faa-0009-08d5-08dd00d0e94c",
                        "email": "tuan_user@platformdevcustomers.onmicrosoft.com",
                        "firstName": "Platform",
                        "lastName": "Owner",
                        "status": "Active",
                        "userGroups": "Account User, Platform Owner, Test User Group 1",
                        "lastLoginTimestamp": "2025-01-06T14:52:40.338954Z"
                    }
                ]
            })
    }, 2000)
})

router.get('/roles', (req, res, next) => {
    setTimeout(() => {
        res
            .status(200)
            .json({
                "pageIndex": 0,
                "pageSize": 25,
                "totalRecords": 39,
                "totalPages": 2,
                "hasPreviousPage": false,
                "hasNextPage": true,
                "data": [
                    {
                        "id": "0192e6f5-e7a0-77bf-8d1c-393cb93def4b",
                        "name": "Account Administrator",
                        "status": "Shared",
                        "abilities": "Configure SSO, Edit company information, View account details",
                        "description": "",
                        "releaseDate": "2024-11-28T12:13:55.839758Z",
                        "rowVersion": "00000000-0000-0000-0000-000000000000",
                        "level": "Tenant"
                    },
                    {
                        "id": "0192e6f8-c9ec-7d98-b2a9-ede8cda5ffdf",
                        "name": "Account Editor",
                        "status": "Shared",
                        "abilities": "Edit company information, View account details",
                        "description": "",
                        "releaseDate": "2025-01-02T06:24:25.857332Z",
                        "rowVersion": "00000000-0000-0000-0000-000000000000",
                        "level": "Tenant"
                    },
                    {
                        "id": "0192e6fc-225f-7ba1-ba9c-ace6af53ba34",
                        "name": "Account IAM Administrator",
                        "status": "Shared",
                        "abilities": "Activate user, Create role, Create user, Create user group, Deactivate user, Delete role, Delete user, Delete user group, Edit role, Edit user, Edit user group, Invite user, Release role, Release user group, View role, View role list, View user, View user group, View user group list, View user list",
                        "description": "",
                        "releaseDate": "2025-01-02T06:24:25.857332Z",
                        "rowVersion": "00000000-0000-0000-0000-000000000000",
                        "level": "Tenant"
                    },
                    {
                        "id": "0192e700-b085-7eff-929a-70e73cae86c4",
                        "name": "Account Owner",
                        "status": "Released",
                        "abilities": "Configure SSO, Edit company information, Transfer tenant ownership, View account details",
                        "description": "",
                        "releaseDate": "2024-11-09T15:12:19.503903Z",
                        "rowVersion": "00000000-0000-0000-0000-000000000000",
                        "level": "Tenant"
                    },
                    {
                        "id": "01903905-4883-76a7-8b4c-0395064f091b",
                        "name": "Account Statistics Viewer",
                        "status": "Released",
                        "abilities": "Export dashboard and report data, Export dashboard or report view, Share filtered dashboard or report view, View account statistics",
                        "description": "",
                        "releaseDate": "2024-11-09T15:12:19.503903Z",
                        "rowVersion": "00000000-0000-0000-0000-000000000000",
                        "level": "Tenant"
                    },
                    {
                        "id": "01903904-11be-732e-92aa-f51327726ff5",
                        "name": "Account Viewer",
                        "status": "Released",
                        "abilities": "View account details",
                        "description": "",
                        "releaseDate": "2024-11-09T15:12:19.503903Z",
                        "rowVersion": "00000000-0000-0000-0000-000000000000",
                        "level": "Tenant"
                    },
                    {
                        "id": "0192f4e9-5a1d-7760-a286-088276b50c90",
                        "name": "Basic Statistics Viewer",
                        "status": "Released",
                        "abilities": "Export dashboard and report data, Export dashboard or report view, Share filtered dashboard or report view",
                        "description": "",
                        "releaseDate": "2024-11-09T15:12:19.503903Z",
                        "rowVersion": "00000000-0000-0000-0000-000000000000",
                        "level": "Tenant"
                    },
                    {
                        "id": "0192e67d-1c87-749e-82da-fdb584ef934f",
                        "name": "Platform Account Administrator",
                        "status": "Released",
                        "abilities": "Configure SSO, Edit company information, Show system information, View account details, View tenant deactivation reason",
                        "description": "",
                        "releaseDate": "2024-11-09T15:12:19.503903Z",
                        "rowVersion": "00000000-0000-0000-0000-000000000000",
                        "level": "Platform"
                    },
                    {
                        "id": "0192f627-a96c-7f46-9898-c90758599d65",
                        "name": "Platform Account Owner",
                        "status": "Released",
                        "abilities": "Configure SSO, Edit company information, Show system information, Transfer tenant ownership, View account details, View tenant deactivation reason",
                        "description": "",
                        "releaseDate": "2024-11-09T15:12:19.503903Z",
                        "rowVersion": "00000000-0000-0000-0000-000000000000",
                        "level": "Platform"
                    },
                    {
                        "id": "01903904-11be-732e-92aa-f511fe24d9dd",
                        "name": "Platform IAM Administrator",
                        "status": "Released",
                        "abilities": "Activate user, Create role, Create user, Create user group, Deactivate user, Delete role, Delete user, Delete user group, Edit role, Edit user, Edit user group, Invite user, Release role, Release user group, Share role, Share user group, View role, View role list, View user, View user group, View user group list, View user list",
                        "description": "",
                        "releaseDate": "2024-11-09T15:12:19.503903Z",
                        "rowVersion": "00000000-0000-0000-0000-000000000000",
                        "level": "Platform"
                    },
                    {
                        "id": "01903904-11be-732e-92aa-f5108825a811",
                        "name": "Platform Tenant Editor",
                        "status": "Released",
                        "abilities": "Edit tenant, View tenant, View tenant deactivation reason, View tenant list",
                        "description": "",
                        "releaseDate": "2024-11-09T15:12:19.503903Z",
                        "rowVersion": "00000000-0000-0000-0000-000000000000",
                        "level": "Platform"
                    },
                    {
                        "id": "01903904-11be-732e-92aa-f50f53c0c6d6",
                        "name": "Platform Tenant Manager",
                        "status": "Released",
                        "abilities": "Activate tenant, Create tenant, Deactivate tenant, Delete tenant, Edit tenant, View tenant, View tenant deactivation reason, View tenant list",
                        "description": "",
                        "releaseDate": "2024-11-09T15:12:19.503903Z",
                        "rowVersion": "00000000-0000-0000-0000-000000000000",
                        "level": "Platform"
                    },
                    {
                        "id": "01903904-11be-732e-92aa-f50e5d43fcbc",
                        "name": "Platform Tenant Viewer",
                        "status": "Released",
                        "abilities": "View tenant, View tenant deactivation reason, View tenant list",
                        "description": "",
                        "releaseDate": "2024-11-09T15:12:19.503903Z",
                        "rowVersion": "00000000-0000-0000-0000-000000000000",
                        "level": "Platform"
                    },
                    {
                        "id": "0192f4e9-5a1d-7182-8e24-cb3609d47674",
                        "name": "Product Sustainability Admin",
                        "status": "Released",
                        "abilities": "PS Admin",
                        "description": "",
                        "releaseDate": "2024-11-09T15:12:19.503903Z",
                        "rowVersion": "00000000-0000-0000-0000-000000000000",
                        "level": "Tenant"
                    },
                    {
                        "id": "0192e69d-f098-7a33-9755-ac83113e940b",
                        "name": "Product Sustainability App Admin",
                        "status": "Released",
                        "abilities": "PS Admin App",
                        "description": "",
                        "releaseDate": "2024-11-09T15:12:19.503903Z",
                        "rowVersion": "00000000-0000-0000-0000-000000000000",
                        "level": "Platform"
                    },
                    {
                        "id": "0192f4ec-96ba-7815-bd1d-85a892f99db1",
                        "name": "Product Sustainability Basic",
                        "status": "Released",
                        "abilities": "PS Basic",
                        "description": "",
                        "releaseDate": "2024-11-09T15:12:19.503903Z",
                        "rowVersion": "00000000-0000-0000-0000-000000000000",
                        "level": "Tenant"
                    },
                    {
                        "id": "0192f4f5-3b5f-755e-8d56-2cdf59e062c9",
                        "name": "Product Sustainability Demo",
                        "status": "Released",
                        "abilities": "PS Demo",
                        "description": "",
                        "releaseDate": "2024-11-09T15:12:19.503903Z",
                        "rowVersion": "00000000-0000-0000-0000-000000000000",
                        "level": "Tenant"
                    },
                    {
                        "id": "0192f4f5-3b5f-705a-b485-656373390a23",
                        "name": "Product Sustainability Early Access",
                        "status": "Released",
                        "abilities": "PS Early Access",
                        "description": "",
                        "releaseDate": "2024-11-09T15:12:19.503903Z",
                        "rowVersion": "00000000-0000-0000-0000-000000000000",
                        "level": "Tenant"
                    },
                    {
                        "id": "0192f4f5-3b5f-71c6-ba38-eaaa3a9f91bc",
                        "name": "Product Sustainability Expert",
                        "status": "Released",
                        "abilities": "PS Expert",
                        "description": "",
                        "releaseDate": "2024-11-09T15:12:19.503903Z",
                        "rowVersion": "00000000-0000-0000-0000-000000000000",
                        "level": "Tenant"
                    },
                    {
                        "id": "0192f4fd-b1b6-73de-a4dc-0592d215c6ec",
                        "name": "Product Sustainability Manager",
                        "status": "Released",
                        "abilities": "PS Manager",
                        "description": "",
                        "releaseDate": "2024-11-09T15:12:19.503903Z",
                        "rowVersion": "00000000-0000-0000-0000-000000000000",
                        "level": "Tenant"
                    },
                    {
                        "id": "0192f4fd-b1b6-7754-baf9-2daccf99edae",
                        "name": "Product Sustainability Preview",
                        "status": "Released",
                        "abilities": "PS Preview",
                        "description": "",
                        "releaseDate": "2024-11-09T15:12:19.503903Z",
                        "rowVersion": "00000000-0000-0000-0000-000000000000",
                        "level": "Tenant"
                    },
                    {
                        "id": "0192f4fd-b1b6-744f-b8b3-b022a9987aab",
                        "name": "Product Sustainability Smart Mapping",
                        "status": "Released",
                        "abilities": "PS Smart Mapping",
                        "description": "",
                        "releaseDate": "2024-11-09T15:12:19.503903Z",
                        "rowVersion": "00000000-0000-0000-0000-000000000000",
                        "level": "Tenant"
                    },
                    {
                        "id": "01903904-11be-732e-92aa-f51483c9b264",
                        "name": "Role Editor",
                        "status": "Released",
                        "abilities": "Create role, Delete role, Edit role, Release role, View role, View role list",
                        "description": "",
                        "releaseDate": "2024-11-09T15:12:19.503903Z",
                        "rowVersion": "00000000-0000-0000-0000-000000000000",
                        "level": "Tenant"
                    },
                    {
                        "id": "01903904-11be-732e-92aa-f515346de741",
                        "name": "Role Viewer",
                        "status": "Released",
                        "abilities": "View role, View role list",
                        "description": "",
                        "releaseDate": "2024-11-09T15:12:19.503903Z",
                        "rowVersion": "00000000-0000-0000-0000-000000000000",
                        "level": "Tenant"
                    },
                    {
                        "id": "0192f509-893e-7a1a-b833-2375a3ab0119",
                        "name": "Sustainability Dashboard Viewer",
                        "status": "Released",
                        "abilities": "View sustainability dashboard",
                        "description": "",
                        "releaseDate": "2024-11-09T15:12:19.503903Z",
                        "rowVersion": "00000000-0000-0000-0000-000000000000",
                        "level": "Tenant"
                    }
                ]
            })
    }, 2000)

})

router.get('/usergroups', (req, res, next) => {
    setTimeout(() => {
        res
            .status(200)
            .json({
                "pageIndex": 0,
                "pageSize": 25,
                "totalRecords": 25,
                "totalPages": 1,
                "hasPreviousPage": false,
                "hasNextPage": true,
                "data": [
                    {
                        "id": "01903892-db11-7ea8-a278-b57ec03a5bd8",
                        "name": "Account Administrator",
                        "status": "Released",
                        "level": "Tenant",
                        "assigned": "No",
                        "roles": "Account Administrator, Account IAM Administrator, Account Statistics Viewer, Role Viewer, User Group Viewer, User Viewer",
                        "releaseDate": "2024-11-09T15:12:19.500192Z",
                        "isSystemUserGroup": false
                    },
                    {
                        "id": "01903892-db11-7407-8462-53e12a781ed0",
                        "name": "Account Owner",
                        "status": "Released",
                        "level": "Tenant",
                        "assigned": "Yes",
                        "roles": "Account Owner, Account Statistics Viewer, Role Viewer, User Group Viewer, User Viewer",
                        "releaseDate": "2024-11-09T15:12:19.500192Z",
                        "isSystemUserGroup": true
                    },
                    {
                        "id": "01903892-db11-76b9-b947-986ff2dbdeab",
                        "name": "Account User",
                        "status": "Released",
                        "level": "Tenant",
                        "assigned": "Yes",
                        "roles": "Account Viewer, User Viewer",
                        "releaseDate": "2024-11-09T15:12:19.500192Z",
                        "isSystemUserGroup": true
                    },
                    {
                        "id": "01903881-050f-783a-9085-edcc2267ed30",
                        "name": "Platform Administrator",
                        "status": "Released",
                        "level": "Platform",
                        "assigned": "No",
                        "roles": "Account Statistics Viewer, Platform Account Administrator, Platform IAM Administrator, Platform Tenant Manager, Tenants Statistics Viewer",
                        "releaseDate": "2024-11-09T15:12:19.500192Z",
                        "isSystemUserGroup": false
                    },
                    {
                        "id": "01903892-db11-7778-999e-c126a8e9dcbb",
                        "name": "Platform Owner",
                        "status": "Released",
                        "level": "Tenant",
                        "assigned": "Yes",
                        "roles": "Account Statistics Viewer, Platform Account Owner, Platform IAM Administrator, Platform Tenant Manager, Tenants Statistics Viewer",
                        "releaseDate": "2024-11-09T15:12:19.500192Z",
                        "isSystemUserGroup": true
                    },
                    {
                        "id": "0192f629-cb4d-7137-8663-186d94fe006d",
                        "name": "Platform Sales and Marketing Department",
                        "status": "Released",
                        "level": "Platform",
                        "assigned": "No",
                        "roles": "Account Viewer, Platform Tenant Viewer, Tenants Statistics Viewer",
                        "releaseDate": "2024-11-09T15:12:19.500192Z",
                        "isSystemUserGroup": false
                    },
                    {
                        "id": "0192f62d-6c97-759f-8429-6e60a6e54fb5",
                        "name": "Platform User",
                        "status": "Released",
                        "level": "Platform",
                        "assigned": "No",
                        "roles": "Account Viewer, Tenants Statistics Viewer, User Viewer",
                        "releaseDate": "2024-11-09T15:12:19.500192Z",
                        "isSystemUserGroup": false
                    },
                    {
                        "id": "0192f693-aa20-7ff3-9fd3-08c9f6a2a5fd",
                        "name": "Sustainability Administrator",
                        "status": "Released",
                        "level": "Tenant",
                        "assigned": "No",
                        "roles": "Product Sustainability Admin",
                        "releaseDate": "2024-11-09T15:12:19.500192Z",
                        "isSystemUserGroup": false
                    },
                    {
                        "id": "0192f62d-6c97-7f81-80de-a5b17163483b",
                        "name": "Sustainability Application Administrator",
                        "status": "Released",
                        "level": "Platform",
                        "assigned": "No",
                        "roles": "Product Sustainability App Admin",
                        "releaseDate": "2024-11-09T15:12:19.500192Z",
                        "isSystemUserGroup": false
                    },
                    {
                        "id": "0192f693-aa20-745e-8a9d-1f1994233928",
                        "name": "Sustainability Basic User",
                        "status": "Released",
                        "level": "Tenant",
                        "assigned": "No",
                        "roles": "Product Sustainability Basic",
                        "releaseDate": "2024-11-09T15:12:19.500192Z",
                        "isSystemUserGroup": false
                    },
                    {
                        "id": "0192f693-aa20-799f-bd2a-cae326562571",
                        "name": "Sustainability Demo User",
                        "status": "Released",
                        "level": "Tenant",
                        "assigned": "No",
                        "roles": "Product Sustainability Demo",
                        "releaseDate": "2024-11-09T15:12:19.500192Z",
                        "isSystemUserGroup": false
                    },
                    {
                        "id": "0192f693-aa20-71f8-9212-caa6ebfd74fc",
                        "name": "Sustainability Early Access",
                        "status": "Released",
                        "level": "Tenant",
                        "assigned": "No",
                        "roles": "Product Sustainability Early Access, Sustainability Dashboard Viewer",
                        "releaseDate": "2024-11-09T15:12:19.500192Z",
                        "isSystemUserGroup": false
                    },
                    {
                        "id": "0192f699-eb16-7878-b555-c8dda999d691",
                        "name": "Sustainability Expert",
                        "status": "Released",
                        "level": "Tenant",
                        "assigned": "No",
                        "roles": "Product Sustainability Expert",
                        "releaseDate": "2024-11-09T15:12:19.500192Z",
                        "isSystemUserGroup": false
                    },
                    {
                        "id": "0192f699-eb16-77ef-82f9-b73518015d6f",
                        "name": "Sustainability Manager",
                        "status": "Released",
                        "level": "Tenant",
                        "assigned": "No",
                        "roles": "Product Sustainability Manager",
                        "releaseDate": "2024-11-09T15:12:19.500192Z",
                        "isSystemUserGroup": false
                    },
                    {
                        "id": "0192f699-eb16-74cf-9c1f-04ce4c96b7c6",
                        "name": "Sustainability Preview",
                        "status": "Released",
                        "level": "Tenant",
                        "assigned": "No",
                        "roles": "Product Sustainability Preview",
                        "releaseDate": "2024-11-09T15:12:19.500192Z",
                        "isSystemUserGroup": false
                    },
                    {
                        "id": "0192f699-eb16-7291-9947-9bdc8a226f24",
                        "name": "Sustainability Smart Mapping",
                        "status": "Released",
                        "level": "Tenant",
                        "assigned": "No",
                        "roles": "Product Sustainability Smart Mapping",
                        "releaseDate": "2024-11-09T15:12:19.500192Z",
                        "isSystemUserGroup": false
                    },
                    {
                        "id": "38130000-0faa-0009-a7f4-08dd093ae657",
                        "name": "Test UG 1",
                        "status": "Draft",
                        "level": "Tenant",
                        "assigned": "No",
                        "roles": "Account Editor, Account IAM Administrator",
                        "releaseDate": null,
                        "isSystemUserGroup": false
                    },
                    {
                        "id": "38130000-0faa-0009-2598-08dd093af0b1",
                        "name": "Test UG 2",
                        "status": "Draft",
                        "level": "Tenant",
                        "assigned": "No",
                        "roles": "Account Administrator, Account Editor, Account IAM Administrator",
                        "releaseDate": null,
                        "isSystemUserGroup": false
                    },
                    {
                        "id": "38130000-0faa-0009-8829-08dd093af93f",
                        "name": "Test UG 3",
                        "status": "Released",
                        "level": "Tenant",
                        "assigned": "No",
                        "roles": "Platform Account Administrator",
                        "releaseDate": "2024-11-20T08:14:16.374788Z",
                        "isSystemUserGroup": false
                    },
                    {
                        "id": "38130000-0faa-0009-4bdf-08dd093b0564",
                        "name": "Test UG 4",
                        "status": "Released",
                        "level": "Tenant",
                        "assigned": "No",
                        "roles": "Account Viewer, Basic Statistics Viewer",
                        "releaseDate": "2024-11-20T08:14:10.649434Z",
                        "isSystemUserGroup": false
                    },
                    {
                        "id": "38130000-0faa-0009-b434-08dd093b1029",
                        "name": "Test UG 5",
                        "status": "Released",
                        "level": "Tenant",
                        "assigned": "No",
                        "roles": "Account IAM Administrator, Account Owner, Account Statistics Viewer, Account Viewer",
                        "releaseDate": "2024-11-20T08:12:48.071007Z",
                        "isSystemUserGroup": false
                    },
                    {
                        "id": "b46e0000-0faa-0009-7666-08dd2af66249",
                        "name": "Test UG 6",
                        "status": "Draft",
                        "level": "Tenant",
                        "assigned": "No",
                        "roles": "Account Viewer, Basic Statistics Viewer",
                        "releaseDate": null,
                        "isSystemUserGroup": false
                    },
                    {
                        "id": "68460000-0faa-0009-edca-08dd00e59465",
                        "name": "Test User Group 1",
                        "status": "Released",
                        "level": "Platform",
                        "assigned": "Yes",
                        "roles": "Tuan Test Role 1",
                        "releaseDate": "2025-01-02T06:18:09.525244Z",
                        "isSystemUserGroup": false
                    },
                    {
                        "id": "68460000-0faa-0009-2358-08dd00ece8c7",
                        "name": "Test User Group 2",
                        "status": "Shared",
                        "level": "Tenant",
                        "assigned": "Yes",
                        "roles": "Test Role 3",
                        "releaseDate": "2024-11-20T08:14:27.913369Z",
                        "isSystemUserGroup": false
                    },
                    {
                        "id": "b46e0000-0faa-0009-18ed-08dd2af3b565",
                        "name": "Tuan UG 1",
                        "status": "Shared",
                        "level": "Tenant",
                        "assigned": "No",
                        "roles": "Account Editor, Account IAM Administrator",
                        "releaseDate": "2025-01-02T06:24:25.846223Z",
                        "isSystemUserGroup": false
                    }
                ]
            })
    }, 2000)

})

router.get('/usergroups/:id', (req, res, next) => {
    console.log('usergroup id: ', req.params.id)

    setTimeout(() => {
        res
            .status(200)
            .json({
                "id": "00000000-0000-0000-0000-000000000000",
                "status": "Shared",
                "name": "Account Administrator",
                "description": "Grants full access to the administration of a company account except of functionalities exclusive to the owner.",
                "level": "Tenant",
                "roles": [
                    {
                        "id": "0192e6f5-e7a0-77bf-8d1c-393cb93def4b",
                        "name": "Account Administrator",
                        "description": "Grants access to general administrative functionalities of a company account.",
                        "level": "Tenant"
                    },
                    {
                        "id": "0192e6fc-225f-7ba1-ba9c-ace6af53ba34",
                        "name": "Account IAM Administrator",
                        "description": "Administers Identity and Access Management ( IAM ) for the company account.",
                        "level": "Tenant"
                    },
                    {
                        "id": "01903905-4883-76a7-8b4c-0395064f091b",
                        "name": "Account Statistics Viewer",
                        "description": "View account statistics dashboard for the company account.",
                        "level": "Tenant"
                    },
                    {
                        "id": "01903904-11be-732e-92aa-f51327726ff5",
                        "name": "Account Viewer",
                        "description": "Grants read-only access to the account management of a company account.",
                        "level": "Tenant"
                    },
                    {
                        "id": "01903904-11be-732e-92aa-f515346de741",
                        "name": "Role Viewer",
                        "description": "Grants read-only access to the role management of a company account.",
                        "level": "Tenant"
                    },
                    {
                        "id": "01903905-4883-76a7-8b4c-03938f0033d2",
                        "name": "User Editor",
                        "description": "Manage user list",
                        "level": "Tenant"
                    },
                    {
                        "id": "01903904-11be-732e-92aa-f516649aa684",
                        "name": "User Group Viewer",
                        "description": "Grants read-only access to the user group management of a company account.",
                        "level": "Tenant"
                    }
                ],
                "rowVersion": "01000000-572e-52ae-6cfd-08dd1f69a2a9"
            })
    }, 2000)

})

router.get('/abilities', (req, res, next) => {
    setTimeout(() => {
        res
            .status(200)
            .json({
                "pageIndex": 0,
                "pageSize": 25,
                "totalRecords": 53,
                "totalPages": 3,
                "hasPreviousPage": false,
                "hasNextPage": true,
                "data": [
                    {
                        "id": "01903a05-79d8-79ee-a741-6696a1c1203f",
                        "name": "Activate tenant",
                        "level": "Platform",
                        "description": "Re-activate a (deactivated) customer tenant within the Tenant Management on the platform account."
                    },
                    {
                        "id": "01903a09-2907-7ebc-a4e8-33638209ae5a",
                        "name": "Activate user",
                        "level": "Tenant",
                        "description": "Re-activate a user within the User Management of the company account."
                    },
                    {
                        "id": "0192ae77-d2c8-7150-8429-41d298fab151",
                        "name": "Configure SSO",
                        "level": "Tenant",
                        "description": "Access the Authentication Management (Account Management → Authentication) of the company account to setup the SSO connection."
                    },
                    {
                        "id": "01903a07-a087-7118-92ef-9090b850e6d5",
                        "name": "Create role",
                        "level": "Tenant",
                        "description": "Create a new role within the Role Management of the company account."
                    },
                    {
                        "id": "01903a05-79d8-7d83-8cf2-bed873700f2d",
                        "name": "Create tenant",
                        "level": "Platform",
                        "description": "Create a new tenant within the Tenant Management on the platform account."
                    },
                    {
                        "id": "01903a09-2907-7b60-8534-8fb748372aae",
                        "name": "Create user",
                        "level": "Tenant",
                        "description": "Create a new user within the User Management of the company account."
                    },
                    {
                        "id": "01903a08-7150-73a8-8dc0-56ef4dc0dad8",
                        "name": "Create user group",
                        "level": "Tenant",
                        "description": "Create a new user group within the User Group Management of the company account."
                    },
                    {
                        "id": "01903a05-79d8-7014-8ab6-37928d8fa0c2",
                        "name": "Deactivate tenant",
                        "level": "Platform",
                        "description": "Deactivate a tenant within the Tenant Management on the platform account."
                    },
                    {
                        "id": "01903a09-2907-76d8-a52b-9f3200fdad12",
                        "name": "Deactivate user",
                        "level": "Tenant",
                        "description": "Deactivate a user within the User Management of the company account.\nDeactivated user cannot access the company tenant anymore."
                    },
                    {
                        "id": "01903a07-a087-78f5-a3eb-3fc10a8ea0d1",
                        "name": "Delete role",
                        "level": "Tenant",
                        "description": "Delete a role within the Role Management of the company account. Shared roles cannot be deleted."
                    },
                    {
                        "id": "01903a05-79d8-7efd-8f16-396f33086a7b",
                        "name": "Delete tenant",
                        "level": "Platform",
                        "description": "Delete a tenant within the Tenant Management on the platform account."
                    },
                    {
                        "id": "01903a09-2907-71b6-a229-bee99148d5af",
                        "name": "Delete user",
                        "level": "Tenant",
                        "description": "Delete a user within the User Management of the company account."
                    },
                    {
                        "id": "01903a08-7150-7a40-8517-89ea71085ad5",
                        "name": "Delete user group",
                        "level": "Tenant",
                        "description": "Delete a user group within the User Group Management of the company account. Shared user groups cannot be deleted."
                    },
                    {
                        "id": "01903a09-2907-78fe-8682-ac608ed019a1",
                        "name": "Edit company information",
                        "level": "Tenant",
                        "description": "Edit company information in the account details of the company account."
                    },
                    {
                        "id": "01903a07-a087-7188-9308-c6c726dae4ff",
                        "name": "Edit role",
                        "level": "Tenant",
                        "description": "Edit the role details within the Role Management of the company account."
                    },
                    {
                        "id": "01903a05-79d8-793e-b9c8-7f497048a23b",
                        "name": "Edit tenant",
                        "level": "Platform",
                        "description": "Edit the details of a tenant within the Tenant Management on the platform account."
                    },
                    {
                        "id": "01903a09-2907-7157-986e-96b12e01247f",
                        "name": "Edit user",
                        "level": "Tenant",
                        "description": "Edit the user details within the User Management of the company account."
                    },
                    {
                        "id": "01903a08-7150-7a1d-a849-4c3656227ac7",
                        "name": "Edit user group",
                        "level": "Tenant",
                        "description": "Edit the user group details within the User Group Management of the company account."
                    },
                    {
                        "id": "0192ae82-0e16-77e1-a248-c45034fa9270",
                        "name": "Export dashboard and report data",
                        "level": "Tenant",
                        "description": "Ability to see and use the PowerBI Export Data option on Dashboard- or Analytics Result widgets."
                    },
                    {
                        "id": "0192ae84-9dfd-7502-9970-64c5a2523759",
                        "name": "Export dashboard or report view",
                        "level": "Tenant",
                        "description": "Ability to see and use the “Export” button on Dashboards or Analytics Results to export its entire view.\nCurrently: Export to pdf, not editable, “you get what you see”-principle, entire view of the dashboard/result (even if it requires scrolling in the application)"
                    },
                    {
                        "id": "0192ae77-d2c8-72f6-9221-021c7d82782d",
                        "name": "Invite user",
                        "level": "Tenant",
                        "description": "Invite users with existing Microsoft Accounts from External Entra ID (client) to the company account."
                    },
                    {
                        "id": "0192ae87-5d38-7e06-99ea-a55127a6a64b",
                        "name": "PS Admin",
                        "level": "Tenant",
                        "description": "Grants access to the Product Sustainability application with the Admin role."
                    },
                    {
                        "id": "0192ae87-5d38-7d06-8de3-77eaa06803b6",
                        "name": "PS Admin App",
                        "level": "Platform",
                        "description": "Grants access to the Product Sustainability application with the Admin App User role."
                    },
                    {
                        "id": "0192ae86-42b5-732c-9c65-318f3f639576",
                        "name": "PS Basic",
                        "level": "Tenant",
                        "description": "Grants access to the Product Sustainability application with the Basic role."
                    },
                    {
                        "id": "0192ae86-42b5-7c13-ab8f-8577e251ce78",
                        "name": "PS Demo",
                        "level": "Tenant",
                        "description": "Grants access to the Product Sustainability application with the Demo role."
                    }
                ]
            })
    }, 2000)

})

export default router