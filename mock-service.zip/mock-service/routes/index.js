import aggregatorRouter from './aggregator.js'
import userManagementRouter from './user-management.js'
import tenantManagementRouter from './tenant-management.js'

const routes = (app) => {
    app.use("/iam/aggregator/api", aggregatorRouter)
    app.use("/iam/user-management/api", userManagementRouter)
    app.use("/iam/tenant-management/api", tenantManagementRouter)
}

export default routes