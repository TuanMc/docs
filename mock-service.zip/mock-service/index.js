import express from 'express'
import routes from './routes/index.js'
import cors from 'cors'

const app = express()
const port = 5001

app.use(express.static('files'))
app.use(cors())

routes(app)

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})  